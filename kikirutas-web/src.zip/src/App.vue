<template>
  <RouterView />
</template>

<script setup lang="ts">
/* App sin headers ni layouts globales.
   Cada sección (User/Admin/Operador) trae su propio layout. */
</script>

