<?php echo e($slot); ?>


<?php if(isset($subcopy)): ?>
<?php echo e($subcopy); ?>

<?php endif; ?>
<?php /**PATH C:\Residencia_Kikirutas\kikirutas-back\resources\views/vendor/mail/text/message.blade.php ENDPATH**/ ?>