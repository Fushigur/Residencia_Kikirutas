<table class="subcopy" width="100%" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td>
<?php echo new \Illuminate\Support\EncodedHtmlString(Illuminate\Mail\Markdown::parse($slot)); ?>

</td>
</tr>
</table>
<?php /**PATH C:\Residencia_Kikirutas\kikirutas-back\resources\views/vendor/mail/html/subcopy.blade.php ENDPATH**/ ?>